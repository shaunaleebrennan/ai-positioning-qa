# Contributing

Thanks for helping make AI-assisted messaging review more useful and accountable.

## Useful contributions

- Propose clearer scoring anchors
- Add a fictional or appropriately licensed worked example
- Identify cases where the rubric produces misleading results
- Improve accessibility and instructions for non-technical users
- Add evaluation fixtures or responsible-use safeguards

## Before submitting

1. Do not include confidential company information, personal data, or private customer quotations.
2. Clearly label fictional, synthetic, adapted, and public-source material.
3. Provide evidence for factual claims and link to the source when licensing permits.
4. Explain the user problem behind the change.
5. Keep recommendations vendor-neutral unless a contribution specifically tests a named system.

## Issues

When reporting a rubric problem, include the relevant dimension, input context, observed result, expected result, and why the difference matters.

## Pull requests

Keep each pull request focused. Describe what changed, why it improves the framework, how you evaluated it, and any remaining limitations.

By contributing, you agree that your contribution will be licensed under the MIT License.

