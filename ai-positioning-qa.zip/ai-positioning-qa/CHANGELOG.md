# Changelog

All notable changes to this project will be documented here.

## 0.1.0 — 2026-08-01

### Added

- Eight-dimension positioning quality rubric
- Weighted scoring method with N/A normalization
- Fictional SignalsDesk worked example
- Reusable messaging evaluation template
- Responsible-use guidance and contribution standards

