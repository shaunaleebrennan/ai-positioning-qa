# AI Positioning QA

An open-source quality-assurance framework for evaluating B2B product messaging before it reaches a homepage, campaign, sales deck, or launch.

AI Positioning QA helps product marketers turn subjective copy feedback into a structured review. It scores messaging across eight dimensions, requires evidence for its conclusions, and keeps final judgment with the marketer.

> Status: v0.1 framework release. The rubric and worked example are ready to use; an interactive evaluator is planned.

## The problem

Messaging reviews often collapse into opinions: “make it punchier,” “lead with value,” or “this could be for anyone.” Generative AI can produce more alternatives, but volume does not guarantee stronger positioning.

This project treats AI as a reviewer rather than an unquestioned author. The goal is to make feedback:

- explicit enough to discuss;
- traceable to the source copy;
- consistent across iterations; and
- useful without pretending positioning can be reduced to one score.

## Who it is for

- Product marketers reviewing a homepage, launch brief, or messaging framework
- Founders pressure-testing early positioning
- Content and growth marketers checking alignment with the core narrative
- Teams experimenting with AI-assisted marketing workflows responsibly

## How it works

1. Define the audience, buying context, alternatives, and available evidence.
2. Submit the messaging asset without asking AI to rewrite it immediately.
3. Score eight dimensions using the [positioning rubric](framework/positioning-rubric.md).
4. Cite the exact language supporting every score.
5. Separate observations, assumptions, and recommendations.
6. Revise the highest-impact weaknesses and evaluate again.

## Scoring model

| Dimension | Weight | Core question |
|---|---:|---|
| ICP specificity | 15% | Is it clear who this is for and when they need it? |
| Problem relevance | 15% | Does it express a meaningful customer problem? |
| Differentiation | 15% | Is the product distinct from the real alternatives? |
| Value articulation | 15% | Are capabilities translated into customer outcomes? |
| Clarity | 15% | Can the intended buyer understand it quickly? |
| Evidence and credibility | 10% | Are important claims supported or supportable? |
| Narrative consistency | 5% | Do the message elements reinforce one another? |
| Responsible AI claims | 10% | Are AI claims specific, proportionate, and transparent? |

The weighted score is a diagnostic, not a verdict. A high score does not establish message-market fit; customer evidence does.

## Try the framework

Start with the [worked fictional example](examples/signalsdesk-worked-example.md), then copy the [evaluation template](evals/evaluation-template.md) for your own review.

For each dimension:

- assign a score from 1 to 5;
- quote or reference the relevant source language;
- state what is missing;
- record confidence as low, medium, or high; and
- recommend one change without rewriting the whole asset.

## Repository map

```text
ai-positioning-qa/
├── README.md
├── framework/
│   └── positioning-rubric.md
├── examples/
│   └── signalsdesk-worked-example.md
├── evals/
│   └── evaluation-template.md
├── CONTRIBUTING.md
├── CHANGELOG.md
└── LICENSE
```

## What this project demonstrates

This repository is also a public product-marketing build. It demonstrates how PMM expertise can be encoded into a repeatable AI workflow while preserving evidence, evaluation, and human accountability.

## Responsible use

- Do not paste confidential customer, company, or personal data into an unapproved AI system.
- Treat generated findings as hypotheses until verified against research and performance data.
- Do not fabricate customer quotations, competitive claims, or proof points.
- Record material assumptions and uncertainty.
- Keep a human owner accountable for the final positioning decision.

## Roadmap

- [ ] Test the rubric against a broader set of fictional and public examples
- [ ] Publish a system prompt with structured output
- [ ] Add machine-readable evaluation fixtures
- [ ] Build a lightweight interactive evaluator
- [ ] Document inter-rater consistency and common failure modes

## Contributing

Feedback from product marketers, founders, researchers, and AI practitioners is welcome. See [CONTRIBUTING.md](CONTRIBUTING.md) before opening an issue or pull request.

## License

Released under the [MIT License](LICENSE).

